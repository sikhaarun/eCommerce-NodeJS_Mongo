const express = require('express');
const app = express();
const bodyParser = require("body-parser");

//code used to parse the request 
app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true  }))


app.listen(3000, function() {
  console.log('listening on 3000')
})

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";
var dbo ;
MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  dbo=db.db("eCommerceDB");

});



app.get('/api/placeanOrder', (req, res) => {

  var query=req.query;
  console.log(query)
  var myobj = { userID: query.userID, productID: query.productID, quantity: query.quantity, price: query.price };
  dbo.collection("Orders").insertOne(myobj, function(err, res) {
    if (err) throw err;
    console.log("1 Order document inserted");
  });
});

app.get('/api/getAllOrders', (req, res) => {

  	 dbo.collection("Orders").find({}).toArray(function(err, result) {
    if (err) throw err;
    console.log(result)
    res.send(result);
  });
});

app.get('/api/getInventory', (req, res) => {
	
  	 dbo.collection("Inventory").find({}).toArray(function(err, result) {
    if (err) throw err;
    console.log(result)
    res.send(result);
  });
});


app.get('/api/placeanOrder', (req, res) => {

  var query=req.query;
  console.log(query)
  var myobj = { userID: query.userID, productID: query.productID, quantity: query.quantity, price: query.price };
  dbo.collection("Orders").insertOne(myobj, function(err, res) {
    if (err) throw err;
    res.send("1 Order document inserted");
  });
});

app.get('/api/createInventory', (req, res) => {

  var query=req.query;
  console.log(query)

  var inventoryobj = { productID: query.productID, location:query.location, quantity: query.quantity };
  dbo.collection("Inventory").insertOne(inventoryobj, function(err, res) {
    if (err) throw err;
    console.log("1 Inventory document inserted");
    res.send("1 Inventory document inserted");
  });

});

app.get('/api/searchOrder', (req, res) => {

  var searchQuery= req.query;//{ productID: "P1" };
  	 dbo.collection("Orders").find(searchQuery).toArray(function(err, result) {
    if (err) throw err;
    
    res.send(result);
  });

});

app.get('/api/updateOrder', (req, res) => {

  var myquery = { userID: "1" };
  var newvalues = { $set: {price: "100"} };
  dbo.collection("Orders").updateOne(myquery, newvalues, function(err, res) {
    if (err) throw err;
    
    res.send(res);
  });

});


 

//api to delete inventory table records according passed query
 app.get('/api/deleteOrder', (req, res) => {

 var deleteQuery= req.query;
  	dbo.collection("Orders").deleteMany(deleteQuery, function(err, obj) {
    if (err) throw err;
    console.log(obj)
    res.send(obj);
  });
});

//api to delete inventory table records according passed query
app.get('/api/deleteInventory', (req, res) => {

 var deleteQuery= req.query;
  	dbo.collection("Inventory").deleteMany(deleteQuery, function(err, obj) {
    if (err) throw err;
    console.log(obj)
    res.send(obj);
  });
});





